<?php /* #?ini charset="utf8"?

[AliasSettings]
AliasList[]=nivoslider

[nivoslider]
Reference=
Filters[]
Filters[]=geometry/scaleexact=300;300
*/ ?>