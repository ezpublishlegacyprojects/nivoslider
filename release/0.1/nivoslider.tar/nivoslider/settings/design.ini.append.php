<?php /* #?ini charset="utf-8"?


[ExtensionSettings]
DesignExtensions[]=nivoslider

[JavaScriptSettings]
CSSFileList[]=jquery-1.5.1.min.js
CSSFileList[]=jquery.nivo.slider.pack.js
FrontendJavaScriptList[]=jquery-1.5.1.min.js
FrontendJavaScriptList[]=jquery.nivo.slider.pack.js


[StylesheetSettings]
CSSFileList[]=nivo-slider.css
FrontendCSSFileList[]=nivo-slider.css
*/
?>
